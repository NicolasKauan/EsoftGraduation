public class Leitor {
    String nome;
    int idLeitor;

    Leitor(String nome, int idLeitor) {
        this.nome = nome;
        this.idLeitor = idLeitor;
    }
}
