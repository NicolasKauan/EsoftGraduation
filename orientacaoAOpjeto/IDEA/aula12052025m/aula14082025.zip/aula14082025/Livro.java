public class Livro {
    String titulo;
    String autor;
    Boolean status;

    Livro(String titulo, String autor, Boolean status) {
        this.titulo = titulo;
        this.autor = autor;
        this.status = status;
    }
}
