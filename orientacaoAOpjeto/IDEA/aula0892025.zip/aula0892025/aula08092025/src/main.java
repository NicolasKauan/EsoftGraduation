public class main {
    public static void main(String[] args) {

        /*Pessoa joao = new Pessoa("joao paulo", "12345678925", 5);

        joao.addTelefone("12345678");
        joao.addTelefone("987654321");
        System.out.printf("------------------------------\n");
        joao.visuTelefone();
        System.out.printf("------------------------------\n");
        joao.removerTelefone("987654321");
        joao.visuTelefone();*/


    }
}
