package exercicios/abstracao/ex3;
public abstract class Forma {
    public abstract double area();
    public abstract double perimetro();
}
