package exercicios/interfaces/ex2;
public interface DispositivoEletronico {
    void ligar();
    void desligar();
}
