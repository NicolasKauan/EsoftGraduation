package exercicios/interfaces/ex5;
public interface Conversor<T, R> {
    R converter(T entrada);
}
