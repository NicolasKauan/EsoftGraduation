package exercicios/interfaces/ex1;
public interface Tributavel {
    double getValorImposto();
}
