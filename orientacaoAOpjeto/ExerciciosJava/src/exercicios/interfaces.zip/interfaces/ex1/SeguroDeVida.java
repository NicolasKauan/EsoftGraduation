package exercicios/interfaces/ex1;
public class SeguroDeVida implements Tributavel {
    @Override public double getValorImposto() { return 42.0; }
}
