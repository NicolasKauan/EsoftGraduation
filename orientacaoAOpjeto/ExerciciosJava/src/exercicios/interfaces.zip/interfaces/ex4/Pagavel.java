package exercicios/interfaces/ex4;
public interface Pagavel {
    double getValorAPagar();
}
