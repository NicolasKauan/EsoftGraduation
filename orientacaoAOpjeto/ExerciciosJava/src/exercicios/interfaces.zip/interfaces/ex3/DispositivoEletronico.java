package exercicios/interfaces/ex3;
public interface DispositivoEletronico {
    void ligar();
    void desligar();
}
