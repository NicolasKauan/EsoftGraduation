package exercicios/interfaces/ex3;
public interface Autenticavel {
    boolean autenticar(String senha);
}
