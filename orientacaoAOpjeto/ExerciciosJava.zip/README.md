
# Exercícios em Java (10 no total)

## Estrutura
### Interfaces
- Ex1-TributavelReceitaFederal
- Ex2-DispositivoEletronico
- Ex3-PortaDeSeguranca
- Ex4-PagavelFinanceiro
- Ex5-Conversores

### Abstração
- Ex1-ContasNextGenBank
- Ex2-GeradorRelatorioTemplateMethod
- Ex3-FormasGeometricas
- Ex4-FuncionariosRH
- Ex5-MeiosDeTransporte

## Como compilar/rodar
Cada exercício é independente e usa o pacote default.
A partir da pasta de cada exercício, rode:
```
javac *.java
java Main
```
Requisitos: JDK 8+.
