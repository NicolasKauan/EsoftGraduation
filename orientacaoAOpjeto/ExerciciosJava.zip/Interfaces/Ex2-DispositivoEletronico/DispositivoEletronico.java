public interface DispositivoEletronico {
    void ligar();
    void desligar();
}
