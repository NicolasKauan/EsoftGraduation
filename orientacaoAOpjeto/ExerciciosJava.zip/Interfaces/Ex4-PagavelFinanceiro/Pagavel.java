public interface Pagavel {
    double getValorAPagar();
}
